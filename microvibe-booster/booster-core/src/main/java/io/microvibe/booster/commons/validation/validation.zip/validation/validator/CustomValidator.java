/*
 * Copyright (c) 2016-9-8 alex
 */

package com.transnal.common.web.api.validation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.transnal.common.spring.ApplicationContextHolder;
import com.transnal.common.web.api.validation.CustomValidation;
import com.transnal.common.web.api.validation.custom.CustomValid;

/**
 * 正则注解验证器
 *
 * @author huangyong
 * @since 1.0.0
 */
public class CustomValidator implements ConstraintValidator<CustomValidation, Object> {

    private Class clazz;

    @Override
    public void initialize(CustomValidation constraintAnnotation) {
        clazz = constraintAnnotation.value();
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {

        CustomValid customValid = (CustomValid) ApplicationContextHolder.getBean(clazz);
        Object result = customValid.isValid(value);


        if (result == null) {
            return false;
        }
        return (boolean) result;
    }
}
