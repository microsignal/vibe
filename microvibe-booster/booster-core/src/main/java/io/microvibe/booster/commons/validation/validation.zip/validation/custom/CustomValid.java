/*
 * Copyright (c) 2016-9-8 alex
 */

package com.transnal.common.web.api.validation.custom;

/**
 * Created by alex on 16/9/8.
 */
public abstract class CustomValid {
   public abstract boolean isValid(Object value);
}
