/*
 * Copyright (c) 2016-9-9 alex
 */

package com.transnal.common.web.api.validation.validator;

import com.transnal.common.web.api.validation.DeleteOrModifyUserValidation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * 正则注解验证器
 *
 * @author huangyong
 * @since 1.0.0
 */
public class DeleteModifyUserValidator implements ConstraintValidator<DeleteOrModifyUserValidation, Object[]> {

    private String value;

    @Override
    public void initialize(DeleteOrModifyUserValidation constraintAnnotation) {
        value = constraintAnnotation.value();
    }

    @Override
    public boolean isValid(Object[] value, ConstraintValidatorContext context) {

      return false;
    }
}
